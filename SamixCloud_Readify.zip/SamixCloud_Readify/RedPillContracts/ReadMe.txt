﻿This project has a reference to the following readify service reference: 

https://knockknock.readify.net/RedPill.svc

All the contracts and data contracts will be used from this service to develop the knock knock web service challenge test.