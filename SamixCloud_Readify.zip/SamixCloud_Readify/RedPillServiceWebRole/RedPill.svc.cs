﻿using RedPillContracts.ReadifyRedPill;
using RedPillLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace RedPillServiceWebRole
{
    public class RedPill : IRedPill
    {
        public Guid WhatIsYourToken()
        {
            ReadifyHelper readifyHelper = new ReadifyHelper();
            return readifyHelper.WhatIsYourToken();
        }
        
        public long FibonacciNumber(long n)
        {
            try
            {
                MathHelper mathHelper = new MathHelper();
                return mathHelper.FibonacciNumber(n);
            }
            catch(ArgumentException ae)
            {
                throw new FaultException(ae.Message);
            }
            catch(Exception)
            {
                throw new FaultException("Error occured: cannot generate Fibonacci number for this n = " + n.ToString());
            }
        }

        public TriangleType WhatShapeIsThis(int a, int b, int c)
        {
            try
            {
                TriangleHelper triangleHelper = new TriangleHelper();
                return triangleHelper.WhatShapeIsThis(a, b, c);
            }
            catch (OverflowException)
            {
                throw new FaultException("Please try to find the shape with different size of the sides.");
            }
            catch (Exception)
            {
                throw new FaultException("Please try to find the shape with different size of the sides.");
            }
        }

        
        public string ReverseWords(string s)
        {
            StringHelper stringHelper = new StringHelper();
            return stringHelper.ReverseWords(s);
        }
    }
}
