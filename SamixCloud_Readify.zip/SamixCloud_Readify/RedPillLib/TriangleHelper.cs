﻿using RedPillContracts.ReadifyRedPill;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RedPillLib
{
    public class TriangleHelper
    {
        /// <summary>
        /// Determines the shape of the triangle based on the sided passed
        /// </summary>
        /// <param name="a">side a</param>
        /// <param name="b">side b</param>
        /// <param name="c">side c</param>
        /// <returns></returns>
        public TriangleType WhatShapeIsThis(int a, int b, int c)
        {
            if (a <= 0 || b <= 0 || c <= 0)
            {
                return TriangleType.Error;
            }

            if(a == b && b == c && c == a)
            {
                return TriangleType.Equilateral;
            }

            int[] sides = new int[3] { a, b, c };
            long c1 = (long)a + (long)b;
            long c2 = (long)b + (long)c;
            long c3 = (long)c + (long)a;

            if (!(c1 > c && c2 > a && c3 > b))
            {
                return TriangleType.Error;
            }

            if (sides.Distinct().Count() == 2)
            {
                return TriangleType.Isosceles;
            }
            else if (sides.Distinct().Count() == 3)
            {
                return TriangleType.Scalene;
            }

            return TriangleType.Error;
        }
    }
}
