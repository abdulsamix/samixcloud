﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RedPillLib
{
    public class MathHelper
    {
        /// <summary>
        /// Returns nth position fibonacci number
        /// </summary>
        /// <param name="n">Position in the sequence</param>
        /// <returns>number in nth position of fibonacci sequence</returns>
        public long FibonacciNumber(long n)
        {
            long i = 0;
            long a = 0;
            long b = 1;
            long c = a + b;

            if (n == 0) return a;
            if (n == 1) return b;

            try
            {
                //Going with positive sequence
                if (n > 1)
                {
                    for (i = 2; i <= n; i++)
                    {
                        c = checked(a + b);
                        a = b;
                        b = c;
                    }
                }
                else//Going with negative sequence
                {
                    if (n == -1) return b;

                    for (i = -2; i >= n; i--)
                    {
                        c = checked(a - b);
                        a = b;
                        b = c;
                    }
                }
                
            }
            catch(OverflowException)
            {
                ArgumentOutOfRangeException ae = new ArgumentOutOfRangeException("n", (i > 0 ? (string.Format("Fib(>{0}) will cause a 64-bit integer overflow.", i - 1))
                    : (string.Format("Fib(<{0}) will cause a 64-bit integer overflow.", i + 1))));
                throw ae;
            }

            return c;
        }
    }
}
