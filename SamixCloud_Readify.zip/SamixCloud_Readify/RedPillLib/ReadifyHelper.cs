﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RedPillLib
{
    public class ReadifyHelper
    {
        /// <summary>
        /// Returns Abdul Sami's token provided by Readify's robot
        /// </summary>
        /// <returns></returns>
        public Guid WhatIsYourToken()
        {
            return Guid.Parse("a0e6f776-1fba-4f02-9150-f9f6279f2773");
        }
    }
}
