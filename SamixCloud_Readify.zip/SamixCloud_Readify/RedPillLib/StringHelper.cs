﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RedPillLib
{
    public class StringHelper
    {
        /// <summary>
        /// Reverses words in a string with out reversing the full string
        /// Ex: "Hello, reverse me." will be reversed as ",olleH esrever .em"
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public string ReverseWords(string s)
        {
            if (s == null) throw new ArgumentNullException("s", "Value cannot be null");

            StringBuilder r = new StringBuilder();
            StringBuilder t = new StringBuilder();
            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] == ' ' || s[i] == '\n' || s[i] == '\r' || s[i] == '\t')
                {
                    if (i == 0)
                    {
                        r.Append(s[i]);
                        continue;
                    }

                    char[] arr = t.ToString().ToArray();
                    Array.Reverse(arr);
                    r.Append(new string(arr));
                    r.Append(s[i]);
                    t.Clear();
                }
                else
                {
                    t.Append(s[i]);
                }

                if (i == s.Length - 1)
                {
                    char[] arr = t.ToString().ToArray();
                    Array.Reverse(arr);
                    r.Append(new string(arr));
                    t.Clear();
                }
            }
            return r.ToString(); 
        }
    }
}
