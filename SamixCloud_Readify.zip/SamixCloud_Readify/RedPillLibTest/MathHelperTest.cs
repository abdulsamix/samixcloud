﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RedPillLib;
using RedPillContracts.ReadifyRedPill;

namespace RedPillLibTest
{
    /// <summary>
    /// Summary description for MathHelperTest
    /// </summary>
    [TestClass]
    public class MathHelperTest
    {
        public MathHelperTest()
        {
            redPillClient = new RedPillClient("BasicHttpBinding_IRedPill");
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        private RedPillClient redPillClient;

        public RedPillClient RedPillClient
        {
            get { return redPillClient; }
            set { redPillClient = value; }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Test_FibonacciNumber_Positive_0()
        {
            MathHelper mathHelper = new MathHelper();
            long result = mathHelper.FibonacciNumber(0);
            Assert.AreEqual(RedPillClient.FibonacciNumber(0), result);
            Assert.AreEqual(0, result);
        }

        [TestMethod]
        public void Test_FibonacciNumber_Positive_1()
        {
            MathHelper mathHelper = new MathHelper();
            long result = mathHelper.FibonacciNumber(1);
            Assert.AreEqual(RedPillClient.FibonacciNumber(1), result);
            Assert.AreEqual(1, result);
        }

        [TestMethod]
        public void Test_FibonacciNumber_Positive_3()
        {
            MathHelper mathHelper = new MathHelper();
            long result = mathHelper.FibonacciNumber(3);
            Assert.AreEqual(RedPillClient.FibonacciNumber(3), result);
            Assert.AreEqual(2, result);
        }

        [TestMethod]
        public void Test_FibonacciNumber_Positive_9()
        {
            MathHelper mathHelper = new MathHelper();
            long result = mathHelper.FibonacciNumber(9);
            Assert.AreEqual(RedPillClient.FibonacciNumber(9), result);
            Assert.AreEqual(34, result);
        }

        [TestMethod]
        public void Test_FibonacciNumber_Negative_1()
        {
            MathHelper mathHelper = new MathHelper();
            long result = mathHelper.FibonacciNumber(-1);
            Assert.AreEqual(RedPillClient.FibonacciNumber(-1), result);
            Assert.AreEqual(1, result);
        }

        [TestMethod]
        public void Test_FibonacciNumber_Negative_8()
        {
            MathHelper mathHelper = new MathHelper();
            long result = mathHelper.FibonacciNumber(-8);
            Assert.AreEqual(RedPillClient.FibonacciNumber(-8), result);
            Assert.AreEqual(-21, result);
        }

        [TestMethod]
        public void Test_FibonacciNumber_Overflow()
        {
            long n = 0;
            long fibn = 0;
            try
            {
                MathHelper mathHelper = new MathHelper();
                for (n = 0; n < long.MaxValue; n++)
                {
                    fibn = mathHelper.FibonacciNumber(n);
                }
                Assert.Fail("An argument exception was not thrown.");
            }
            catch (ArgumentOutOfRangeException ae)
            {
                Assert.AreEqual(typeof(ArgumentOutOfRangeException), ae.GetType());
                Console.WriteLine("n = " + n + " will raise overflow exception.");
            }
            catch (Exception ex)
            {
                Assert.AreEqual(typeof(ArgumentException), ex.GetType());
            }
        }
    }
}
