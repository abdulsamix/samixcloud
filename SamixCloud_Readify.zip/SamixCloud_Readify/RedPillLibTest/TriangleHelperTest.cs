﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RedPillLib;
using RedPillContracts.ReadifyRedPill;

namespace RedPillLibTest
{
    /// <summary>
    /// Summary description for TriangleHelperTest
    /// </summary>
    [TestClass]
    public class TriangleHelperTest
    {
        public TriangleHelperTest()
        {
            redPillClient = new RedPillClient("BasicHttpBinding_IRedPill");
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        private RedPillClient redPillClient;

        public RedPillClient RedPillClient
        {
            get { return redPillClient; }
            set { redPillClient = value; }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestInitialize()]
        public void MyTestInitialize() 
        { 

        }
        

        [TestMethod]
        public void Test_WhatShapeIsThis_Equilateral()
        {
            TriangleHelper triangleHelper = new TriangleHelper();
            TriangleType result = triangleHelper.WhatShapeIsThis(4, 4, 4);
            Assert.AreEqual(RedPillClient.WhatShapeIsThis(4, 4, 4), result);
            Assert.AreEqual(TriangleType.Equilateral, result);
        }

        [TestMethod]
        public void Test_WhatShapeIsThis_Isosceles()
        {
            TriangleHelper triangleHelper = new TriangleHelper();
            TriangleType result = triangleHelper.WhatShapeIsThis(4, 4, 2);
            Assert.AreEqual(RedPillClient.WhatShapeIsThis(4, 4, 2), result);
            Assert.AreEqual(TriangleType.Isosceles, result);
        }

        [TestMethod]
        public void Test_WhatShapeIsThis_Scalene()
        {
            TriangleHelper triangleHelper = new TriangleHelper();
            TriangleType result = triangleHelper.WhatShapeIsThis(4, 5, 6);
            Assert.AreEqual(RedPillClient.WhatShapeIsThis(4, 5, 6), result);
            Assert.AreEqual(TriangleType.Scalene, result);
        }

        [TestMethod]
        public void Test_WhatShapeIsThis_ErrorZero()
        {
            TriangleHelper triangleHelper = new TriangleHelper();
            TriangleType result = triangleHelper.WhatShapeIsThis(0, 0, 0);
            Assert.AreEqual(RedPillClient.WhatShapeIsThis(0, 0, 0), result);
            Assert.AreEqual(TriangleType.Error, result);
        }

        [TestMethod]
        public void Test_WhatShapeIsThis_ErrorNegative()
        {
            TriangleHelper triangleHelper = new TriangleHelper();
            TriangleType result = triangleHelper.WhatShapeIsThis(-1, -2, -3);
            Assert.AreEqual(RedPillClient.WhatShapeIsThis(-1, -2, -3), result);
            Assert.AreEqual(TriangleType.Error, result);
        }

        [TestMethod]
        public void Test_WhatShapeIsThis_Boundary1()
        {
            TriangleHelper triangleHelper = new TriangleHelper();
            TriangleType result = triangleHelper.WhatShapeIsThis(int.MaxValue, int.MaxValue, int.MaxValue - 1);
            Assert.AreEqual(RedPillClient.WhatShapeIsThis(int.MaxValue, int.MaxValue, int.MaxValue - 1), result);
            Assert.AreEqual(TriangleType.Isosceles, result);
        }

        [TestMethod]
        public void Test_WhatShapeIsThis_Boundary2()
        {
            TriangleHelper triangleHelper = new TriangleHelper();
            TriangleType result = triangleHelper.WhatShapeIsThis(int.MaxValue, int.MaxValue, int.MaxValue);
            Assert.AreEqual(RedPillClient.WhatShapeIsThis(int.MaxValue, int.MaxValue, int.MaxValue), result);
            Assert.AreEqual(TriangleType.Equilateral, result);
        }
    }
}
