﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RedPillLib;
using RedPillContracts.ReadifyRedPill;

namespace RedPillLibTest
{
    /// <summary>
    /// Summary description for StringHelperTest
    /// </summary>
    [TestClass]
    public class StringHelperTest
    {
        public StringHelperTest()
        {
            redPillClient = new RedPillClient("BasicHttpBinding_IRedPill");
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        private RedPillClient redPillClient;

        public RedPillClient RedPillClient
        {
            get { return redPillClient; }
            set { redPillClient = value; }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Test_ReverseWords_Null()
        {

            try
            {
                StringHelper stringHelper = new StringHelper();
                string result = stringHelper.ReverseWords(null);
                Assert.AreEqual(RedPillClient.ReverseWords(null), result);
                Assert.Fail("An argument null exception was not thrown.");
            }
            catch (ArgumentNullException ae)
            {
                Assert.AreEqual(typeof(ArgumentNullException), ae.GetType());
            }
            catch (Exception ex)
            {
                Assert.AreEqual(typeof(ArgumentNullException), ex.GetType());
            } 
        }

        [TestMethod]
        public void Test_ReverseWords_Simple()
        {
            StringHelper stringHelper = new StringHelper();
            string input = "Hello, reverse me!";
            string result = stringHelper.ReverseWords(input);
            Assert.AreEqual(RedPillClient.ReverseWords(input), result);
            Assert.AreEqual(",olleH esrever !em", result);
        }

        [TestMethod]
        public void Test_ReverseWords_Complex()
        {
            StringHelper stringHelper = new StringHelper();
            string input = "ABc!@ ~-=#$% 5454 `?*";
            string result = stringHelper.ReverseWords(input);
            Assert.AreEqual(RedPillClient.ReverseWords(input), result);
            Assert.AreEqual("@!cBA %$#=-~ 4545 *?`", result);
        }

        [TestMethod]
        public void Test_ReverseWords_CarraigeReturn()
        {
            StringHelper stringHelper = new StringHelper();
            string input = "\r\ntest hello\r\ntest";
            string result = stringHelper.ReverseWords(input);
            Assert.AreEqual(RedPillClient.ReverseWords(input), result);
            Assert.AreEqual("\r\ntset olleh\r\ntset", result);
        }

        [TestMethod]
        public void Test_ReverseWords_Tab()
        {
            StringHelper stringHelper = new StringHelper();
            string input = "\ttest hello\ttest";
            string result = stringHelper.ReverseWords(input);
            Assert.AreEqual(RedPillClient.ReverseWords(input), result);
            Assert.AreEqual("\ttset olleh\ttset", result);
        }

        [TestMethod]
        public void Test_ReverseWords_NewLine()
        {
            StringHelper stringHelper = new StringHelper();
            string input = "\ntest hello\ntest";
            string result = stringHelper.ReverseWords(input);
            Assert.AreEqual(RedPillClient.ReverseWords(input), result);
            Assert.AreEqual("\ntset olleh\ntset", result);
        }
    }
}
