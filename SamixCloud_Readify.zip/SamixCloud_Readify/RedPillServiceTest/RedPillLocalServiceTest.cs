﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Local = RedPillServiceTest.RedPillLocalService;

namespace RedPillServiceTest
{
    [TestClass]
    public class RedPillLocalServiceTest
    {
        public RedPillLocalServiceTest()
        {
            redPillClientLocal = new Local.RedPillClient("BasicHttpBinding_IRedPillL");
        }

        private Local.RedPillClient redPillClientLocal;

        public Local.RedPillClient RedPillClientLocal
        {
            get { return redPillClientLocal; }
        }

        [TestMethod]
        public void LocalServiceEndpointTest()
        {
            //Info: testing a simple test case
            Guid result = RedPillClientLocal.WhatIsYourToken();
            Assert.AreEqual(Guid.Parse("a0e6f776-1fba-4f02-9150-f9f6279f2773"), result);
        }
    }
}
