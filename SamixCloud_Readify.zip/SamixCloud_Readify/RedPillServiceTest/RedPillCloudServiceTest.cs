﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Cloud = RedPillServiceTest.RedPillCloudService;
using System.ServiceModel;

namespace RedPillServiceTest
{
    [TestClass]
    public class RedPillCloudServiceTest
    {
        public RedPillCloudServiceTest()
        {
            redPillClientCloud = new Cloud.RedPillClient("BasicHttpBinding_IRedPillC");
        }

        private Cloud.RedPillClient redPillClientCloud;

        public Cloud.RedPillClient RedPillClientCloud
        {
            get { return redPillClientCloud; }
        }

        [TestMethod]
        public void CloudServiceEndpointTest()
        {
            //Info: testing a simple test case
            Guid result = RedPillClientCloud.WhatIsYourToken();
            Assert.AreEqual(Guid.Parse("a0e6f776-1fba-4f02-9150-f9f6279f2773"), result);
        }
    }
}
